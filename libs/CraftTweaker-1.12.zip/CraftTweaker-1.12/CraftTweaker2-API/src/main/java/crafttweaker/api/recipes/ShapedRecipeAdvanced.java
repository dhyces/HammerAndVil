package crafttweaker.api.recipes;

@Deprecated
public class ShapedRecipeAdvanced {}
