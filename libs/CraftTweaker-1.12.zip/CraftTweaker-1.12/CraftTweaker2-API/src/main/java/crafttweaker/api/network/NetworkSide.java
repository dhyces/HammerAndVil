package crafttweaker.api.network;

public enum NetworkSide {
    INVALID_SIDE,
    SIDE_CLIENT,
    SIDE_SERVER
}
